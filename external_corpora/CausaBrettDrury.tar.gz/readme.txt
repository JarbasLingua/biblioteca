This resource is intended to be a gold standard for Portuguese causative relation classification or annotation. The details of this gold standard and a wider resource it is part of can be found at: http://www.lbd.dcc.ufmg.br/colecoes/torporesp/2014/010.pdf. Please cite this paper if you use this resource.

Suggested citation:

@INPROCEEDINGS{drurylexical,
  title={Lexical Resources for the Identification of Causative Relations in Portuguese Texts},
  author={Drury, Brett and Cardoso, Paula CF and Thomas, Janie M and de Andrade Lopes, Alneu}
 booktitle = {Proceedings of Workshop on Tools and Resources for Automatically Processing Portuguese and Spanish},
year ={2014}
}

License: This resource is released under Creative Commons Attribution-NoDerivatives 4.0 International. Details of the license can be found here: http://creativecommons.org/licenses/by-nd/4.0/

Author Contact: brett.drury@outlook.com 



